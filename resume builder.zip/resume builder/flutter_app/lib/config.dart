class ApiConfig {
  // Change this to your deployed backend URL later.
  static const String baseUrl = "http://127.0.0.1:5000";
}

